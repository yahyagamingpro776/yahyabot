const fs = require('fs');
const path = require('path');
const settings = require('./settings');
const db = JSON.parse(fs.readFileSync('./database.json', 'utf-8'));

// حفظ قاعدة البيانات
function saveDatabase() {
    fs.writeFileSync('./database.json', JSON.stringify(db, null, 2));
    console.log('✅ تم حفظ قاعدة البيانات');
}

// الحصول على مستوى المستخدم
function getUserLevel(xp) {
    let level = Math.floor(xp / 100);
    if (level > settings.games.maxLevel) level = settings.games.maxLevel;
    
    let levelTitle = db.levels["0"];
    for (let i = 100; i >= 0; i -= 10) {
        if (level >= i && db.levels[i]) {
            levelTitle = db.levels[i];
            break;
        }
    }
    
    return { level, title: levelTitle };
}

// إضافة XP للمستخدم
function addXP(userId, groupId, xp) {
    if (!db.users[userId]) {
        db.users[userId] = {
            name: '',
            xp: 0,
            level: 0,
            wins: 0,
            gamesPlayed: 0,
            medals: { gold: 0, silver: 0, bronze: 0, participation: 0 },
            profile: { realName: '', favoriteCharacter: '', age: '', country: '' }
        };
    }
    
    db.users[userId].xp += xp;
    db.users[userId].gamesPlayed++;
    const newLevel = getUserLevel(db.users[userId].xp);
    
    if (newLevel.level > db.users[userId].level) {
        db.users[userId].level = newLevel.level;
        return { leveledUp: true, newLevel: newLevel.level, title: newLevel.title };
    }
    
    saveDatabase();
    return { leveledUp: false };
}

// الأوامر المتاحة
const commands = {
    // الأوامر العامة
    '.اوامر': async (sock, msg, args) => {
        const helpText = `🎮 *قائمة أوامر بوت Yahya* 🎮

*🎲 أوامر الألعاب:*
• .العاب - عرض قائمة الألعاب المتاحة
• .فعاليات - بدأ جولة ألعاب
• .ترتيب - عرض ترتيب اللاعبين
• .ملفي - عرض ملفك الشخصي

*🎨 أوامر الملصقات:*
• .ستيكر - تحويل الصورة إلى ملصق
• .رد على الصورة بـ .ستيكر

*⚔️ أوامر الفرق:*
• .فريق [اسم الفريق] - إنشاء فريق
• .انضم [اسم الفريق] - الانضمام لفريق
• .تحدي [فريق1] [فريق2] - بدأ تحد بين الفرق
• .نتيجة - عرض نتيجة التحدي

*🎲 لعبة النرد:*
• .نرد - بدأ لعبة صراحة أو تحدي
• .انسحاب - الانسحاب من اللعبة
• .اخرج [منشن] - إخراج لاعب (للمنظم)

*🛡️ أوامر الحماية (للمشرفين):*
• .منع روابط - منع الروابط في المجموعة
• .منع فويس - منع الرسائل الصوتية
• .سماح روابط - السماح بالروابط
• .سماح فويس - السماح بالرسائل الصوتية
• .طرد [منشن] - طرد عضو من المجموعة

*👤 أوامر الملف الشخصي:*
• .تسجيل [الاسم] [الشخصية] [العمر] [الدولة] - تسجيل بياناتك
• .ملفي - عرض ملفك الشخصي

*ℹ️ أوامر أخرى:*
• .المطور - معلومات المطور
• .عن البوت - معلومات عن البوت

📊 *نظام المستويات:*
كل إجابة صحيحة = 10 XP
المركز الأول = +5 XP
المركز الثاني = +3 XP
المركز الثالث = +2 XP

🔰 *رتب المستويات:*
0-9: مبتدئ
10-19: لاعب طموح
20-29: لاعب متقدم
30-39: منافس قوي
40-49: مغامر جريء
50-59: مقاتل صنديد
60-69: قائد النخبة
70-79: خبير محترف
80-89: لا يقهر
90-99: نجم ساطع
100+: أسطورة السيرفر

*البوت من تطوير يحيى (NK)* 🇲🇷
*الإصدار:* ${settings.botVersion}`;

        await sock.sendMessage(msg.key.remoteJid, { text: helpText }, { quoted: msg });
    },

    '.العاب': async (sock, msg, args) => {
        const gamesList = `🎮 *قائمة الألعاب المتوفرة* 🎮

1️⃣ 🌍 *أعلام* - تخمين اسم الدولة من العلم
2️⃣ 😎 *إيموجي* - تكرار الإيموجي بسرعة
3️⃣ 🔄 *عكس* - عكس الكلمة المكتوبة
4️⃣ 🧩 *تفكيك* - فك الكلمة المشوشة
5️⃣ 🧮 *رياضيات* - حل مسائل رياضية
6️⃣ 📺 *كرتون* - أسئلة عن الكرتونات
7️⃣ 🎌 *أنمي* - أسئلة عن الأنميات
8️⃣ 🦸‍♂️ *شخصيات* - تخمين أسماء الشخصيات
9️⃣ 🕋 *دين* - أسئلة دينية إسلامية
🔟 🧠 *ألغاز* - ألغاز وثقافة عامة

*لبدأ أي لعبة:* .فعاليات [رقم اللعبة]
*مثال:* .فعاليات 1 (لبدأ لعبة الأعلام)

📊 *جوائز كل جولة:*
🏆 المركز الأول: 5 XP + ميدالية ذهبية
🥈 المركز الثاني: 3 XP + ميدالية فضية
🥉 المركز الثالث: 2 XP + ميدالية برونزية
🎖️ المشاركة: 1 XP + ميدالية مشاركة`;

        await sock.sendMessage(msg.key.remoteJid, { text: gamesList }, { quoted: msg });
    },

    '.فعاليات': async (sock, msg, args) => {
        const gameId = parseInt(args[0]);
        const groupId = msg.key.remoteJid;
        
        if (!groupId.endsWith('@g.us')) {
            await sock.sendMessage(groupId, { text: '❌ هذا الأمر متاح فقط في المجموعات!' }, { quoted: msg });
            return;
        }
        
        if (db.games[groupId] && db.games[groupId].active) {
            await sock.sendMessage(groupId, { text: '⚠️ هناك لعبة نشطة حالياً! انتظر حتى تنتهي.' }, { quoted: msg });
            return;
        }
        
        if (gameId < 1 || gameId > 10 || isNaN(gameId)) {
            await sock.sendMessage(groupId, { text: '❌ يرجى اختيار رقم لعبة صحيح!\nاستخدم .العاب لمعرفة الألعاب المتاحة' }, { quoted: msg });
            return;
        }
        
        // بدأ اللعبة
        const gameNames = {
            1: 'أعلام', 2: 'إيموجي', 3: 'عكس', 4: 'تفكيك',
            5: 'رياضيات', 6: 'كرتون', 7: 'أنمي', 8: 'شخصيات', 9: 'دين', 10: 'ألغاز'
        };
        
        if (!db.games[groupId]) db.games[groupId] = {};
        
        db.games[groupId].active = true;
        db.games[groupId].type = gameId;
        db.games[groupId].name = gameNames[gameId];
        db.games[groupId].currentQuestion = 0;
        db.games[groupId].players = {};
        db.games[groupId].scores = {};
        db.games[groupId].questions = [];
        
        // تحميل الأسئلة حسب نوع اللعبة
        let questions = [];
        switch(gameId) {
            case 1: questions = [...db.questions.flags]; break;
            case 2: questions = [...db.questions.emoji]; break;
            case 3: questions = [...db.questions.reverse]; break;
            case 4: questions = [...db.questions.unscramble]; break;
            case 5: questions = [...db.questions.math]; break;
            case 6: questions = [...db.questions.cartoon]; break;
            case 7: questions = [...db.questions.anime]; break;
            case 8: questions = [...db.questions.characters]; break;
            case 9: questions = [...db.questions.religion]; break;
            case 10: questions = [...db.questions.riddles]; break;
        }
        
        // اختيار 5 أسئلة عشوائية
        const shuffled = questions.sort(() => 0.5 - Math.random());
        db.games[groupId].questions = shuffled.slice(0, 5);
        
        saveDatabase();
        
        const startMsg = `🎮 *بدأت الفعالية!* 🎮

📌 *نوع اللعبة:* ${gameNames[gameId]}
📊 *عدد الأسئلة:* 5 أسئلة
⏱️ *مدة كل سؤال:* 30 ثانية

✨ *استعدوا! السؤال الأول قريب...*
💡 *للإجابة:* أرسل الإجابة مباشرة في المجموعة`;
        
        await sock.sendMessage(groupId, { text: startMsg }, { quoted: msg });
        
        // بدأ السؤال الأول بعد 3 ثواني
        setTimeout(async () => {
            await askQuestion(sock, groupId);
        }, 3000);
    },
    
    '.ستيكر': async (sock, msg, args) => {
        // التحقق من وجود صورة
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        let imageMsg = null;
        
        if (quotedMsg && quotedMsg.imageMessage) {
            imageMsg = quotedMsg.imageMessage;
        } else if (msg.message?.imageMessage) {
            imageMsg = msg.message.imageMessage;
        }
        
        if (!imageMsg) {
            await sock.sendMessage(msg.key.remoteJid, { text: '❌ يرجى الرد على صورة أو إرسال صورة مع الأمر .ستيكر' }, { quoted: msg });
            return;
        }
        
        // إظهار أن البوت يعالج
        await sock.sendMessage(msg.key.remoteJid, { react: { text: '⏳', key: msg.key } });
        
        try {
            // تحميل الصورة
            const stream = await sock.downloadMediaMessage({ message: { imageMessage: imageMsg } });
            const buffer = Buffer.from(stream);
            
            // إرسال كملصق
            await sock.sendMessage(msg.key.remoteJid, { 
                sticker: buffer,
                mimetype: 'image/webp'
            }, { quoted: msg });
            
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '✅', key: msg.key } });
        } catch (error) {
            console.error('Error creating sticker:', error);
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            await sock.sendMessage(msg.key.remoteJid, { text: '❌ فشل في تحويل الصورة إلى ملصق' }, { quoted: msg });
        }
    },
    
    '.تسجيل': async (sock, msg, args) => {
        const userId = msg.key.participant || msg.key.remoteJid;
        const [realName, favoriteCharacter, age, country] = args;
        
        if (!realName || !favoriteCharacter || !age || !country) {
            await sock.sendMessage(msg.key.remoteJid, { 
                text: '❌ الاستخدام الصحيح:\n.تسجيل [الاسم] [الشخصية المفضلة] [العمر] [الدولة]\nمثال: .تسجيل يحيى ناروتو 19 موريتانيا'
            }, { quoted: msg });
            return;
        }
        
        if (!db.users[userId]) {
            db.users[userId] = {
                name: '',
                xp: 0,
                level: 0,
                wins: 0,
                gamesPlayed: 0,
                medals: { gold: 0, silver: 0, bronze: 0, participation: 0 },
                profile: {}
            };
        }
        
        db.users[userId].name = realName;
        db.users[userId].profile = { realName, favoriteCharacter, age, country };
        saveDatabase();
        
        await sock.sendMessage(msg.key.remoteJid, { 
            text: `✅ *تم التسجيل بنجاح!* 🎉
            
📝 *البيانات المسجلة:*
👤 الاسم: ${realName}
⭐ الشخصية المفضلة: ${favoriteCharacter}
🎂 العمر: ${age}
🌍 الدولة: ${country}

✨ استخدم .ملفي لعرض ملفك الشخصي`
        }, { quoted: msg });
    },
    
    '.ملفي': async (sock, msg, args) => {
        const userId = msg.key.participant || msg.key.remoteJid;
        
        if (!db.users[userId]) {
            await sock.sendMessage(msg.key.remoteJid, { 
                text: '❌ لم تقم بالتسجيل بعد!\nاستخدم .تسجيل [الاسم] [الشخصية] [العمر] [الدولة] للتسجيل'
            }, { quoted: msg });
            return;
        }
        
        const user = db.users[userId];
        const levelInfo = getUserLevel(user.xp);
        
        const profileText = `👤 *الملف الشخصي*

📝 *الاسم:* ${user.profile.realName || 'غير مسجل'}
⭐ *الشخصية المفضلة:* ${user.profile.favoriteCharacter || 'غير مسجلة'}
🎂 *العمر:* ${user.profile.age || 'غير مسجل'}
🌍 *الدولة:* ${user.profile.country || 'غير مسجلة'}

📊 *الإحصائيات:*
🎮 XP: ${user.xp}
🏆 المستوى: ${levelInfo.level} ${levelInfo.title}
🎯 عدد الانتصارات: ${user.wins}
🎲 عدد الألعاب: ${user.gamesPlayed}

🏅 *الميداليات:*
🥇 ذهبية: ${user.medals.gold}
🥈 فضية: ${user.medals.silver}
🥉 برونزية: ${user.medals.bronze}
🎖️ مشاركة: ${user.medals.participation}

✨ *استمر في اللعب لرفع مستواك!* ✨`;
        
        await sock.sendMessage(msg.key.remoteJid, { text: profileText }, { quoted: msg });
    },
    
    '.ترتيب': async (sock, msg, args) => {
        const groupId = msg.key.remoteJid;
        
        if (!db.games[groupId] || !db.games[groupId].scores) {
            await sock.sendMessage(groupId, { text: '❌ لا توجد لعبة نشطة حالياً!' }, { quoted: msg });
            return;
        }
        
        const scores = db.games[groupId].scores;
        const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
        
        let leaderboard = `🏆 *ترتيب اللاعبين* 🏆\n\n`;
        
        for (let i = 0; i < Math.min(sorted.length, 10); i++) {
            const [userId, score] = sorted[i];
            let medal = '';
            if (i === 0) medal = '🥇 ';
            else if (i === 1) medal = '🥈 ';
            else if (i === 2) medal = '🥉 ';
            else medal = `${i+1}. `;
            
            leaderboard += `${medal} ${db.users[userId]?.name || 'لاعب'}: ${score} نقطة\n`;
        }
        
        leaderboard += `\n📊 *السؤال:* ${db.games[groupId].currentQuestion + 1}/${db.games[groupId].questions.length}`;
        
        await sock.sendMessage(groupId, { text: leaderboard }, { quoted: msg });
    },
    
    '.المطور': async (sock, msg, args) => {
        const devInfo = `👨‍💻 *معلومات المطور*

📛 *الاسم:* يحيى
🏷️ *اللقب:* NK
🎂 *العمر:* 19 سنة
🌍 *البلد:* موريتانيا 🇲🇷
⭐ *الشخصية:* ماسلمان

📞 *للتواصل:*
• رقم المطور: ${settings.developerNumber}
• رقم البوت: ${settings.pairingNumber}

🎮 *البوت:* Yahya Bot
📌 *الإصدار:* ${settings.botVersion}

✨ *شكراً لاستخدام بوت Yahya* ✨`;
        
        await sock.sendMessage(msg.key.remoteJid, { text: devInfo }, { quoted: msg });
    },
    
    '.عن البوت': async (sock, msg, args) => {
        const botInfo = `🤖 *عن بوت Yahya*

📌 *الاسم:* Yahya Bot
📌 *الإصدار:* ${settings.botVersion}
📌 *المطور:* يحيى (NK)
📌 *البلد:* موريتانيا 🇲🇷
📌 *النوع:* بوت واتساب متكامل

✨ *المميزات:*
• 🎮 10 أنواع مختلفة من الألعاب
• 🛡️ نظام حماية متكامل
• 🎨 صناعة الملصقات
• ⚔️ نظام الفرق والمنافسات
• 🎲 لعبة صراحة أو تحدي
• 📊 نظام XP ومستويات

📊 *قاعدة البيانات:*
• 400+ سؤال متنوع
• 63 علم دولة
• أسئلة في 10 مجالات مختلفة

🎯 *الرؤية:* تقديم تجربة ترفيهية متكاملة للمستخدمين العرب

*البوت مفتوح المصدر ويمكن تطويره* 💻`;
        
        await sock.sendMessage(msg.key.remoteJid, { text: botInfo }, { quoted: msg });
    }
};

// دالة لعرض السؤال
async function askQuestion(sock, groupId) {
    const game = db.games[groupId];
    if (!game || !game.active) return;
    
    if (game.currentQuestion >= game.questions.length) {
        await endGame(sock, groupId);
        return;
    }
    
    const question = game.questions[game.currentQuestion];
    let questionText = `📌 *السؤال ${game.currentQuestion + 1}/${game.questions.length}*\n\n`;
    
    switch(game.type) {
        case 1: // أعلام
            questionText += `🌍 *تخمين الدولة:*\n${question.flag}\n💡 ${question.hint}`;
            break;
        case 2: // إيموجي
            questionText += `😎 *كرر هذا الإيموجي:*\n${question.emoji.repeat(question.repeat)}`;
            break;
        case 3: // عكس
            questionText += `🔄 *اكتب الكلمة معكوسة:*\n${question.word}`;
            break;
        case 4: // تفكيك
            questionText += `🧩 *فك الكلمة المشوشة:*\n${question.scrambled}`;
            break;
        case 5: // رياضيات
            questionText += `🧮 *حل المسألة:*\n${question.question}`;
            break;
        case 6: // كرتون
        case 7: // أنمي
        case 8: // شخصيات
        case 9: // دين
        case 10: // ألغاز
            questionText += `❓ *${question.question || question.riddle}*`;
            break;
    }
    
    questionText += `\n\n⏱️ *الوقت:* 30 ثانية\n💡 *أرسل إجابتك الآن!*`;
    
    await sock.sendMessage(groupId, { text: questionText });
    
    // تعيين المؤقت
    game.questionTimeout = setTimeout(async () => {
        if (db.games[groupId] && db.games[groupId].active) {
            await sock.sendMessage(groupId, { text: `⏰ *انتهى الوقت!*\nالإجابة الصحيحة: ${question.answer || question.country || question.emoji || question.word || question.reversed || question.character}\n\n📌 السؤال القادم...` });
            game.currentQuestion++;
            await askQuestion(sock, groupId);
        }
    }, 30000);
}

// دالة لإنهاء اللعبة
async function endGame(sock, groupId) {
    const game = db.games[groupId];
    if (!game) return;
    
    const scores = Object.entries(game.scores).sort((a, b) => b[1] - a[1]);
    
    let resultText = `🏆 *نتيجة الفعالية* 🏆\n\n🎮 *نوع اللعبة:* ${game.name}\n📊 *النتائج:*\n\n`;
    
    for (let i = 0; i < Math.min(scores.length, 5); i++) {
        const [userId, score] = scores[i];
        let medal = '';
        let xpBonus = 0;
        
        if (i === 0) {
            medal = '🥇';
            xpBonus = settings.games.xpFirstPlace;
            if (db.users[userId]) db.users[userId].medals.gold++;
        } else if (i === 1) {
            medal = '🥈';
            xpBonus = settings.games.xpSecondPlace;
            if (db.users[userId]) db.users[userId].medals.silver++;
        } else if (i === 2) {
            medal = '🥉';
            xpBonus = settings.games.xpThirdPlace;
            if (db.users[userId]) db.users[userId].medals.bronze++;
        } else {
            medal = '🎖️';
            xpBonus = settings.games.xpFourthFifth;
            if (db.users[userId]) db.users[userId].medals.participation++;
        }
        
        const levelResult = addXP(userId, groupId, settings.games.xpPerCorrect * score + xpBonus);
        if (levelResult.leveledUp) {
            resultText += `${medal} ${db.users[userId]?.name || 'لاعب'}: ${score} نقطة (+${settings.games.xpPerCorrect * score + xpBonus} XP)\n🎉 *رُفع المستوى إلى ${levelResult.level} ${levelResult.title}!*\n\n`;
        } else {
            resultText += `${medal} ${db.users[userId]?.name || 'لاعب'}: ${score} نقطة (+${settings.games.xpPerCorrect * score + xpBonus} XP)\n\n`;
        }
        
        if (i === 0 && db.users[userId]) db.users[userId].wins++;
    }
    
    resultText += `✨ *شكراً للمشاركة! استخدم .فعاليات للعبة جديدة* ✨`;
    
    await sock.sendMessage(groupId, { text: resultText });
    
    // حذف بيانات اللعبة
    delete db.games[groupId];
    saveDatabase();
}

// دالة للتحقق من الإجابات
async function checkAnswer(sock, msg, text) {
    const groupId = msg.key.remoteJid;
    if (!groupId.endsWith('@g.us')) return false;
    
    const game = db.games[groupId];
    if (!game || !game.active) return false;
    
    const currentQ = game.questions[game.currentQuestion];
    const userId = msg.key.participant || msg.key.remoteJid;
    let isCorrect = false;
    
    // التحقق من الإجابة حسب نوع اللعبة
    switch(game.type) {
        case 1: // أعلام
            if (text.toLowerCase() === currentQ.country.toLowerCase()) isCorrect = true;
            break;
        case 2: // إيموجي
            if (text === currentQ.emoji.repeat(currentQ.repeat)) isCorrect = true;
            break;
        case 3: // عكس
            if (text.toLowerCase() === currentQ.reversed.toLowerCase()) isCorrect = true;
            break;
        case 4: // تفكيك
            if (text.toLowerCase() === currentQ.word.toLowerCase()) isCorrect = true;
            break;
        case 5: // رياضيات
            if (text === currentQ.answer) isCorrect = true;
            break;
        case 6: // كرتون
        case 7: // أنمي
        case 8: // شخصيات
        case 9: // دين
        case 10: // ألغاز
            if (text.toLowerCase() === (currentQ.answer || currentQ.character).toLowerCase()) isCorrect = true;
            break;
    }
    
    if (isCorrect && !game.scores[userId]) {
        game.scores[userId] = 0;
    }
    
    if (isCorrect && game.scores[userId] < 1) {
        game.scores[userId]++;
        await sock.sendMessage(groupId, { text: `✅ ${db.users[userId]?.name || 'لاعب'} أجاب إجابة صحيحة! (+1 نقطة)` }, { quoted: msg });
        
        // إذا كان هذا هو أول إجابة صحيحة، انتقل للسؤال التالي
        if (game.scores[userId] === 1) {
            clearTimeout(game.questionTimeout);
            game.currentQuestion++;
            await askQuestion(sock, groupId);
        }
        
        return true;
    }
    
    return false;
}

module.exports = { commands, checkAnswer, askQuestion, endGame, addXP, getUserLevel };