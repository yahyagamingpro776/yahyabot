const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, Browsers } = require('@whiskeysockets/baileys');
const Pino = require('pino');
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const settings = require('./settings');
const { commands, checkAnswer } = require('./commands');

console.log(chalk.cyan(`
╔═══════════════════════════════════════╗
║        🤖 YAHYA BOT v${settings.botVersion}        ║
║          بواسطة: ${settings.developer}           ║
║            🇲🇷 موريتانيا 🇲🇷             ║
╚═══════════════════════════════════════╝
`));

// إنشاء مجلد للجلسة إذا لم يكن موجوداً
if (!fs.existsSync('./auth_info')) {
    fs.mkdirSync('./auth_info');
}

// حفظ قاعدة البيانات تلقائياً
let saveInterval;
let backupInterval;

// بدأ البوت
async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('./auth_info');
    
    const sock = makeWASocket({
        auth: state,
        logger: Pino({ level: 'silent' }),
        browser: Browsers.windows('Desktop'),
        printQRInTerminal: true,
        defaultQueryTimeoutMs: undefined,
        keepAliveIntervalMs: 10000,
        emitOwnEvents: true
    });
    
    // حفظ بيانات الجلسة
    sock.ev.on('creds.update', saveCreds);
    
    // عند الاتصال
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        if (qr) {
            console.log(chalk.yellow('📱 اسحب رمز الـ QR من الواتساب:'));
            console.log(qr);
        }
        
        if (connection === 'open') {
            console.log(chalk.green('✅ البوت متصل بنجاح!'));
            console.log(chalk.blue('🤖 Yahya Bot جاهز للعمل'));
            
            // بدأ الحفظ التلقائي
            if (settings.database.autoSave) {
                saveInterval = setInterval(() => {
                    try {
                        const db = JSON.parse(fs.readFileSync('./database.json', 'utf-8'));
                        fs.writeFileSync('./database.json', JSON.stringify(db, null, 2));
                        console.log(chalk.gray('💾 تم حفظ قاعدة البيانات تلقائياً'));
                    } catch (err) {
                        console.error(chalk.red('❌ خطأ في حفظ قاعدة البيانات:'), err);
                    }
                }, settings.database.autoSaveInterval);
            }
            
            // بدأ النسخ الاحتياطي
            if (settings.database.backupEnabled) {
                backupInterval = setInterval(() => {
                    try {
                        const backupPath = `./backups/database_${Date.now()}.json`;
                        if (!fs.existsSync('./backups')) fs.mkdirSync('./backups');
                        const db = JSON.parse(fs.readFileSync('./database.json', 'utf-8'));
                        fs.writeFileSync(backupPath, JSON.stringify(db, null, 2));
                        console.log(chalk.gray(`💾 تم إنشاء نسخة احتياطية: ${backupPath}`));
                        
                        // حذف النسخ القديمة (احتفظ بآخر 10 نسخ)
                        const backups = fs.readdirSync('./backups');
                        if (backups.length > 10) {
                            backups.sort().slice(0, -10).forEach(file => {
                                fs.unlinkSync(`./backups/${file}`);
                            });
                        }
                    } catch (err) {
                        console.error(chalk.red('❌ خطأ في النسخ الاحتياطي:'), err);
                    }
                }, settings.database.backupInterval);
            }
        }
        
        if (connection === 'close') {
            console.log(chalk.red('❌ تم قطع الاتصال'));
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            if (statusCode === DisconnectReason.loggedOut) {
                console.log(chalk.yellow('🔄 تم تسجيل الخروج، يرجى إعادة تشغيل البوت'));
                process.exit();
            } else {
                console.log(chalk.yellow('🔄 محاولة إعادة الاتصال...'));
                startBot();
            }
        }
    });
    
    // معالجة الرسائل
    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || msg.key.fromMe) return;
        
        const messageText = msg.message.conversation || 
                           msg.message.extendedTextMessage?.text || 
                           msg.message.imageMessage?.caption || '';
        
        const groupId = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        
        // التحقق من الأوامر
        if (messageText.startsWith('.')) {
            const args = messageText.slice(1).trim().split(/\s+/);
            const commandName = args[0].toLowerCase();
            const commandArgs = args.slice(1);
            
            if (commands[commandName]) {
                try {
                    await commands[commandName](sock, msg, commandArgs);
                    console.log(chalk.cyan(`📨 تم تنفيذ الأمر: ${commandName} من ${sender}`));
                } catch (error) {
                    console.error(chalk.red(`❌ خطأ في تنفيذ الأمر ${commandName}:`), error);
                    await sock.sendMessage(groupId, { 
                        text: '❌ حدث خطأ أثناء تنفيذ الأمر. يرجى المحاولة مرة أخرى.' 
                    }, { quoted: msg });
                }
            }
        }
        
        // التحقق من الإجابات في الألعاب
        if (messageText && !messageText.startsWith('.')) {
            try {
                const isAnswer = await checkAnswer(sock, msg, messageText);
                if (isAnswer) {
                    console.log(chalk.green(`✅ إجابة صحيحة من ${sender}: ${messageText}`));
                }
            } catch (error) {
                console.error(chalk.red('❌ خطأ في التحقق من الإجابة:'), error);
            }
        }
        
        // نظام منع السبام
        if (settings.protection.antiSpam) {
            // يمكن إضافة نظام منع السبام هنا
        }
    });
    
    // معالجة الأخطاء
    process.on('uncaughtException', (error) => {
        console.error(chalk.red('❌ خطأ غير متوقع:'), error);
    });
    
    process.on('unhandledRejection', (reason, promise) => {
        console.error(chalk.red('❌ وعد غير معالج:'), reason);
    });
}

// إغلاق البوت بشكل آمن
process.on('SIGINT', () => {
    console.log(chalk.yellow('\n🛑 جاري إيقاف البوت...'));
    if (saveInterval) clearInterval(saveInterval);
    if (backupInterval) clearInterval(backupInterval);
    
    // حفظ قاعدة البيانات قبل الإغلاق
    try {
        const db = JSON.parse(fs.readFileSync('./database.json', 'utf-8'));
        fs.writeFileSync('./database.json', JSON.stringify(db, null, 2));
        console.log(chalk.green('💾 تم حفظ قاعدة البيانات'));
    } catch (err) {
        console.error(chalk.red('❌ خطأ في حفظ قاعدة البيانات:'), err);
    }
    
    console.log(chalk.green('✅ تم إيقاف البوت'));
    process.exit(0);
});

// بدأ البوت
startBot().catch(err => {
    console.error(chalk.red('❌ فشل بدأ البوت:'), err);
});