const fs = require('fs');
const path = require('path');

// إعدادات البوت
const settings = {
    // معلومات البوت
    botName: 'Yahya Bot',
    botVersion: '1.2.0',
    developer: 'يحيى (NK)',
    developerNumber: '22226845038',
    pairingNumber: '22234000076',
    
    // إعدادات الألعاب
    games: {
        xpPerCorrect: 10,
        xpFirstPlace: 5,
        xpSecondPlace: 3,
        xpThirdPlace: 2,
        xpFourthFifth: 1,
        maxLevel: 100,
        questionsPerGame: 5,
        timePerQuestion: 30000, // 30 ثانية
    },
    
    // إعدادات الحماية
    protection: {
        antiSpam: true,
        spamThreshold: 5, // عدد الرسائل المتكررة
        spamTimeframe: 10000, // 10 ثواني
        antiLinks: true,
        antiVoice: true,
        antiMedia: false,
    },
    
    // إعدادات المجموعة
    group: {
        welcomeMessage: true,
        goodbyeMessage: true,
        mentionEvery: 7200000, // ساعتين
        maxTeams: 10,
        maxTeamMembers: 20,
    },
    
    // إعدادات قاعدة البيانات
    database: {
        autoSave: true,
        autoSaveInterval: 60000, // كل دقيقة
        backupEnabled: true,
        backupInterval: 3600000, // كل ساعة
    },
    
    // الرسائل الافتراضية
    messages: {
        welcome: '🎉 *مرحباً بك* {name}\n📊 معرف: {id}\n👥 عدد الأعضاء: {count}\n💫 *استمتع مع بوت {botName}*',
        goodbye: '👋 *وداعاً* {name}\n📊 معرف: {id}\n👥 عدد الأعضاء المتبقين: {count}',
        notAdmin: '❌ *عذراً* هذا الأمر متاح فقط للمشرفين!',
        notDeveloper: '❌ *عذراً* هذا الأمر متاح فقط للمطور!',
        botNotAdmin: '⚠️ *تنبيه* يرجى جعل البوت مشرفاً لتفعيل جميع الميزات!',
    }
};

module.exports = settings;